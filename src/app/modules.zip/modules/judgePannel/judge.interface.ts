



export interface IJudge {
  panel: string;
  description: string;
  members: {
    name: string;
    designation: string;
    image: string;
  }[];
}

